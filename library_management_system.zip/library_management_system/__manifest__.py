{
    'name': 'Library Management System',
    'version': '1.0',
    'summary': 'A module to manage library operations',
    'description': 'This module allows you to manage books, authors, and borrowing records in a library.',
    'author': 'Naroth',
    'depends': [],
    'data': [
        'security/ir.model.access.csv',
        'views/category_view.xml',
        'views/book_view.xml',
        'views/member_view.xml',
        'views/borrow_view.xml',
        'views/menu_item.xml',
        'views/addons_view.xml'
    ],
    'installable': True,
    'application': True,
}