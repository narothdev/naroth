from odoo import models , fields,api
 
class LibraryBorrow (models.Model):
    _name = "library.borrow"
    _description = "Library Borrow"
    
    member_id=fields.Many2one(comodel_name="library.member")
    book_id=fields.Many2one(comodel_name="library.book", domain=[('is_available', '=', True)],required=True)
    borrow_date = fields.Date(string="Borrow Date" , default=fields.Date.context_today )
    return_date = fields.Date(string="Return Date")
    state = fields.Selection(
        string="State",
        selection=[('draft','Draft'),('borrowed','Borrowed'),('returned','Returned')],
        default='draft'
    )

    @api.model
    def create(self, vals):
        record = super(LibraryBorrow, self).create(vals)
        if record.book_id:
            record.book_id.is_available = False
        return record

    # def write(self, vals):
    #     record = super(LibraryBorrow, self).write(vals)
    #     if vals.get('state') == 'returned':
    #         self.book_id.is_available = True
    #     return record

    def action_borrow(self):
        self.state = 'borrowed'
        self.book_id.is_available = False
    def action_return(self):
        self.state = 'returned'
        self.book_id.is_available = True
        self.return_date = fields.Date.context_today(self)

