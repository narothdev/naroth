from odoo import models,fields

class LibraryBook(models.Model):
    _name = "library.book"
    _description = "Library Book"

    name = fields.Char(string="Book Name", required=True)
    author = fields.Char(string="Author")
    ibns=fields.Char(string="IBNS")
    price=fields.Float(string="Price")
    publish_date=fields.Date(string="Publish Date")
    is_available=fields.Boolean(string="Is Available", default=True ,readonly=True)
    category_id=fields.Many2one(comodel_name="library.category",string="Category ID")
    borrow_ids=fields.One2many(comodel_name="library.borrow",inverse_name="book_id",string="Borrower ID")