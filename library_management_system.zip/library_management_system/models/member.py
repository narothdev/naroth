from odoo import models,fields ,api


class LibraryMember (models.Model):
    _name = "library.member"
    _description = "Library Member"

    name=fields.Char(string="Name")
    email=fields.Char(string="Email")
    phone=fields.Char(string="Phone")
    active=fields.Boolean(string="Active",default=True)
    borrow_ids=fields.One2many(comodel_name="library.borrow",inverse_name="member_id")
    borrow_count = fields.Integer(string="Borrow Count", compute="_compute_borrow_count")
    @api.depends('borrow_ids')
    def _compute_borrow_count(self):
        for member in self:
            member.borrow_count = len(member.borrow_ids)

    